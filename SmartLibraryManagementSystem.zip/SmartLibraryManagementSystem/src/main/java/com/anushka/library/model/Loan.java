package com.anushka.library.model;

import java.time.LocalDate;

public class Loan {
    private int id, bookId, memberId;
    private LocalDate issueDate, dueDate, returnDate;
    private double fine;
    private String status;

    public Loan(int id,int bookId,int memberId,LocalDate issueDate,LocalDate dueDate,
                LocalDate returnDate,double fine,String status){
        this.id=id;this.bookId=bookId;this.memberId=memberId;this.issueDate=issueDate;
        this.dueDate=dueDate;this.returnDate=returnDate;this.fine=fine;this.status=status;
    }
    public int getId(){return id;} public int getBookId(){return bookId;}
    public int getMemberId(){return memberId;} public LocalDate getIssueDate(){return issueDate;}
    public LocalDate getDueDate(){return dueDate;} public LocalDate getReturnDate(){return returnDate;}
    public double getFine(){return fine;} public String getStatus(){return status;}
}
