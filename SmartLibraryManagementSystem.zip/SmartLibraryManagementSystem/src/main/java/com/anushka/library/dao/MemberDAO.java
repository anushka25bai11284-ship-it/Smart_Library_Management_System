package com.anushka.library.dao;

import com.anushka.library.db.Database;
import com.anushka.library.model.Member;
import java.sql.*;
import java.util.*;

public class MemberDAO {
    public void add(Member m)throws SQLException{
        String q="INSERT INTO members(name,email,phone) VALUES(?,?,?)";
        try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement(q)){
            p.setString(1,m.getName());p.setString(2,m.getEmail());p.setString(3,m.getPhone());p.executeUpdate();
        }
    }
    public List<Member> all()throws SQLException{
        List<Member> list=new ArrayList<>();
        try(Connection c=Database.getConnection();PreparedStatement p=c.prepareStatement("SELECT * FROM members ORDER BY name");
            ResultSet r=p.executeQuery()){while(r.next())list.add(new Member(r.getInt("id"),r.getString("name"),r.getString("email"),r.getString("phone")));}
        return list;
    }
}
