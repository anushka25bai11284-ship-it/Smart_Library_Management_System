# UML / Diagram Content

## Use Case Diagram
Actors: Librarian, Member.
Use cases: Manage Books, Manage Members, Search Books, Issue Book, Return Book, Calculate Fine, View Dashboard, Get Recommendations.

## Class Diagram
Main classes:
Main -> LibraryFrame
LibraryFrame -> BookDAO, MemberDAO, LoanService, RecommendationService, ReportService
BookDAO -> Book
MemberDAO -> Member
LoanService -> Loan
All DAO/service classes -> Database

## Sequence Diagram: Issue Book
Librarian -> LibraryFrame -> LoanService -> Database
LoanService checks availability -> inserts loan -> decreases available copies -> returns success.

## ER Diagram
BOOKS 1 --- * LOANS * --- 1 MEMBERS

BOOKS:
id, title, author, category, isbn, total_copies, available_copies

MEMBERS:
id, name, email, phone

LOANS:
id, book_id, member_id, issue_date, due_date, return_date, fine, status
