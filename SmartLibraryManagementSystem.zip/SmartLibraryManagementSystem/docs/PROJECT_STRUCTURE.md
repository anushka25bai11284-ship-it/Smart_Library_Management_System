# Project Structure

- `Main.java` — application entry point.
- `Database.java` — SQLite connection and schema creation.
- `Book.java`, `Member.java`, `Loan.java` — domain/model classes.
- `BookDAO.java`, `MemberDAO.java` — database access.
- `LoanService.java` — issue/return transactions and fine calculation.
- `RecommendationService.java` — rule-based smart recommendation.
- `ReportService.java` — dashboard metrics.
- `Validator.java` — input validation.
- `LibraryFrame.java` — Swing user interface.

This gives more than the required 5–10 meaningful classes/files and separates UI, business logic, data access and models.
