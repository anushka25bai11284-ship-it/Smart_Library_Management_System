# Smart Library Management System — Project Report

## 1. Cover Page
**Project Title:** Smart Library Management System  
**Student:** Anushka Dubey  
**Course:** Java / Build Your Own Project  
**Technology:** Java 17, Swing, JDBC, SQLite

## 2. Introduction
Libraries manage large numbers of books, members and circulation transactions. Manual registers and simple catalog systems can make searching, tracking availability, handling overdue books and discovering useful resources inefficient. The Smart Library Management System is a Java desktop application that centralizes these operations. It provides book and member management, circulation, automatic fine calculation, reports and a rule-based recommendation feature.

## 3. Problem Statement
A library needs a reliable system to maintain its catalog and member records, track book circulation and reduce manual work. The project addresses these needs through a modular Java application with persistent SQLite storage.

## 4. Objectives
- Digitize book and member records.
- Simplify book search and availability checking.
- Automate issue and return transactions.
- Calculate overdue fines automatically.
- Provide simple personalized book recommendations.
- Generate useful library statistics.
- Demonstrate Java OOP, JDBC, exception handling, collections and modular design.

## 5. Functional Requirements
1. Add and delete books.
2. Search books by title, author or category.
3. Register members.
4. Issue books to members.
5. Return books and calculate fines.
6. Recommend books using borrowing history.
7. Display dashboard statistics.
8. Validate user input and handle database errors.

## 6. Non-Functional Requirements
- Performance: common catalog operations should complete quickly for normal academic-library datasets.
- Usability: operations are exposed through a simple Swing interface.
- Reliability: issue/return transactions use database transactions.
- Maintainability: UI, services, DAO and models are separated.
- Error handling: invalid input and SQL errors are displayed as messages.
- Resource efficiency: JDBC connections are opened only for required operations.

## 7. System Architecture
Presentation Layer: Swing GUI  
Business Layer: LoanService, RecommendationService, ReportService  
Data Access Layer: BookDAO, MemberDAO  
Data Layer: SQLite database via JDBC

## 8. Design Diagrams
Include the Use Case, Workflow, Sequence, Class and ER diagrams described in `docs/UML_NOTES.md`.

## 9. Design Decisions & Rationale
Java was selected because the project is intended to demonstrate Java programming concepts. Swing provides a desktop UI without requiring a separate frontend framework. SQLite reduces deployment complexity while still demonstrating relational database operations through JDBC. DAO classes isolate SQL from business logic. The recommendation engine is intentionally rule-based so its behavior can be explained and tested in an academic viva.

## 10. Implementation Details
The application starts through `Main.java`, initializes the database and opens `LibraryFrame`. Models represent books, members and loans. DAOs perform database operations. `LoanService` performs issue/return operations and fine calculations. `RecommendationService` identifies categories frequently borrowed by a member and suggests available books in those categories. `Validator` checks required fields, positive values and email format.

## 11. Smart Recommendation Logic
The system counts the categories of books previously borrowed by a member. The most frequently borrowed categories are selected, and available books from those categories are presented as recommendations. This is a simple content/category-based approach rather than a trained machine-learning model.

## 12. Testing
Testing includes valid and invalid input, book availability, issue/return behavior, overdue fine calculation, searching, recommendations and dashboard counts. Refer to `docs/TEST_CASES.md`.

## 13. Expected Results
The application should maintain persistent book/member/loan records, update availability after issue and return, calculate fines for overdue returns and produce recommendations when borrowing history exists.

## 14. Challenges
- Designing a clean separation between UI and database code.
- Maintaining consistent book availability.
- Handling transaction failures.
- Validating user input.
- Making recommendations useful without training a machine-learning model.

## 15. Learnings
- Java OOP and modular design.
- JDBC and relational persistence.
- SQL queries.
- Exception handling and validation.
- GUI development with Swing.
- Transaction management.
- Basic recommendation-system logic.
- Git/GitHub project organization.

## 16. Future Enhancements
- Role-based authentication.
- Book reservation and waiting lists.
- Barcode/QR scanning.
- Email reminders.
- Advanced recommendation algorithms.
- Cloud database and web/mobile interface.
- Fine payment integration.
- Detailed librarian analytics.

## 17. References
- Java Platform Documentation
- JDBC API documentation
- SQLite documentation
- Maven documentation
