# Workflow

Login/Start -> Dashboard -> Choose Module

Books -> Add/Search/Delete -> Catalog Updated
Members -> Register -> Member Record Created
Issue -> Enter Book ID + Member ID -> Check Availability -> Create Loan -> Decrease Available Copies
Return -> Enter Loan ID -> Calculate Overdue Days -> Calculate Fine -> Close Loan -> Increase Available Copies
Recommendations -> Enter Member ID -> Analyze Borrowing Categories -> Show Available Suggestions
Reports -> Read Current Counts -> Display Dashboard
