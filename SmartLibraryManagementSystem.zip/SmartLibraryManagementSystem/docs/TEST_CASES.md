# Test Cases

| ID | Test | Expected Result |
|---|---|---|
| T01 | Add book with valid data | Book appears in catalog |
| T02 | Add book with empty title | Validation error |
| T03 | Register valid member | Member appears in member list |
| T04 | Register invalid email | Validation error |
| T05 | Issue available book | Available copies decrease |
| T06 | Issue unavailable book | Operation rejected |
| T07 | Return active loan | Available copies increase |
| T08 | Return overdue loan | Fine is calculated at ₹5/day |
| T09 | Search by title/category | Matching books shown |
| T10 | Recommendation for new member | Helpful fallback message |
| T11 | Recommendation for member with history | Books from frequently borrowed categories shown |
| T12 | Dashboard refresh | Current counts displayed |
